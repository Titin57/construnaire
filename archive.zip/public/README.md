###public/

Ce répertoire 3 éléments : 

* index.php : le contrôleur frontal de l'application
* Le .htaccess : redirigea toutes les requêtes vers le contrôleur frontal
* Le répertoire assets/ (contenant les fichiers .css et .js, les images, etc.)

Votre nom de domaine doit pointer ici, et non à la racine de votre projet. 